/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*test.html", "./**/*.html"], // <-- ye sab html files include karega
  theme: {
    extend: {},
  },
  plugins: [],
}



   

